package com.qunar.mybatis.spring.enums;

/**
 * Created with IntelliJ IDEA. User: guolifei Date: 2018/8/1
 */
public enum BookStateEnum {

    PUTAWAY(0, "上架"), SOLDOUT(1, "下架"), WAITBUY(2, "待采购");

    private int state;

    private String stateInfo;

    BookStateEnum(int state, String stateInfo) {
        this.state = state;
        this.stateInfo = stateInfo;
    }

    public static BookStateEnum stateOf(int code) {
        for (BookStateEnum state : values()) {
            if (state.getState() == code) {
                return state;
            }
        }
        return null;
    }

    public int getState() {
        return state;
    }

    public String getStateInfo() {
        return stateInfo;
    }
}
