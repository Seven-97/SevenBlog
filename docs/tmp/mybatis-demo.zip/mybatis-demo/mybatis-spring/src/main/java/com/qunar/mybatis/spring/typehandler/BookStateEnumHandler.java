package com.qunar.mybatis.spring.typehandler;

import com.qunar.mybatis.spring.enums.BookStateEnum;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created with IntelliJ IDEA. User: guolifei Date: 2018/8/2
 */
public class BookStateEnumHandler extends BaseTypeHandler<BookStateEnum> {

    public void setNonNullParameter(PreparedStatement preparedStatement, int i, BookStateEnum bookStateEnum, JdbcType jdbcType) throws SQLException {
        preparedStatement.setInt(i, bookStateEnum.getState());
    }

    public BookStateEnum getNullableResult(ResultSet resultSet, String s) throws SQLException {
        int state = resultSet.getInt(s);
        if (resultSet.wasNull()) {
            return null;
        } else {
            return BookStateEnum.stateOf(state);
        }
    }

    public BookStateEnum getNullableResult(ResultSet resultSet, int i) throws SQLException {
        int state = resultSet.getInt(i);
        if (resultSet.wasNull()) {
            return null;
        } else {
            return BookStateEnum.stateOf(state);
        }
    }

    public BookStateEnum getNullableResult(CallableStatement callableStatement, int i) throws SQLException {
        int state = callableStatement.getInt(i);
        if (callableStatement.wasNull()) {
            return null;
        } else {
            return BookStateEnum.stateOf(state);
        }
    }
}
