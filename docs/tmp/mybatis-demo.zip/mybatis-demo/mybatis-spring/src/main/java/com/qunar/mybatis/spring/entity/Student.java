package com.qunar.mybatis.spring.entity;

import java.util.List;

/**
 * Created with IntelliJ IDEA. User: guolifei Date: 2018/8/1
 */
public class Student {

    private long studentId;

    private String name;

    private List<Appointment> appointments;

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Appointment> getAppointments() {
        return appointments;
    }

    public void setAppointments(List<Appointment> appointments) {
        this.appointments = appointments;
    }

    @Override
    public String toString() {
        return "Student{" +
                "studentId=" + studentId +
                ", name='" + name + '\'' +
                '}';
    }
}
