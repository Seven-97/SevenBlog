package com.qunar.mybatis.spring.dao;


import com.qunar.mybatis.spring.entity.Student;

/**
 * Created with IntelliJ IDEA. User: guolifei Date: 2018/8/1
 */
public interface StudentDao {

    /**
     * 通过ID查询学生
     *
     * @param id
     * @return
     */
    Student queryById(long id);

}
