package com.qunar.mybatis.spring.exception;

/**
 * Created with IntelliJ IDEA. User: guolifei Date: 2018/8/1
 * 重复预约异常
 */
public class RepeatAppointException extends RuntimeException {

    public RepeatAppointException(String message) {
        super(message);
    }

    public RepeatAppointException(String message, Throwable cause) {
        super(message, cause);
    }

}
