package com.qunar.mybatis.springboot.exception;

/**
 * Created with IntelliJ IDEA. User: guolifei Date: 2018/8/1
 * 库存不足异常
 */
public class NoNumberException extends RuntimeException {

    public NoNumberException(String message) {
        super(message);
    }

    public NoNumberException(String message, Throwable cause) {
        super(message, cause);
    }

}
