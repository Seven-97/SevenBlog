package com.qunar.mybatis.springboot.dao;

import com.qunar.mybatis.springboot.entity.Appointment;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * Created with IntelliJ IDEA. User: guolifei Date: 2018/8/1
 */
public interface AppointmentDao {

    /**
     * 插入预约图书记录
     *
     * @param bookId
     * @param studentId
     * @return 插入的行数
     */
    @Insert("INSERT ignore INTO appointment (book_id, student_id) VALUES (#{bookId}, #{studentId})")
    int insertAppointment(@Param("bookId") long bookId, @Param("studentId") long studentId);


    @Select("SELECT * FROM appointment WHERE student_id = #{studentId}")
    List<Appointment> getAppointments(long studentId);

    /**
     * 通过主键查询预约图书记录，并且携带图书实体
     *
     * @param bookId
     * @param studentId
     * @return
     */
    @Select(" SELECT\n" +
            "        a.book_id,\n" +
            "        a.student_id,\n" +
            "        a.appoint_time,\n" +
            "        b.book_id \"book.book_id\",\n" +
            "        b.`name` \"book.name\",\n" +
            "        b.number \"book.number\"\n" +
            "        FROM\n" +
            "        appointment a\n" +
            "        INNER JOIN book b ON a.book_id = b.book_id\n" +
            "        WHERE\n" +
            "        a.book_id = #{bookId}\n" +
            "        AND a.student_id = #{studentId}")
    Appointment queryByKeyWithBook(@Param("bookId") long bookId, @Param("studentId") long studentId);

}
