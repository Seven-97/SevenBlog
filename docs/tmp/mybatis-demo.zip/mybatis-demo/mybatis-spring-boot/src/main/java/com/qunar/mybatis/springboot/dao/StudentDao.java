package com.qunar.mybatis.springboot.dao;


import com.qunar.mybatis.springboot.entity.Student;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * Created with IntelliJ IDEA. User: guolifei Date: 2018/8/1
 */
public interface StudentDao {

    /**
     * 通过ID查询学生
     *
     * @param id
     * @return
     */
    @Select("SELECT * FROM student WHERE student_id = #{id}")
    @Results({
            @Result(property = "studentId", column = "student_id"),
            @Result(property = "name", column = "name"),
            @Result(property = "appointments", javaType = List.class, column = "student_id",
                    many = @Many(select = "com.qunar.mybatis.springboot.dao.AppointmentDao.getAppointments"))
    })
    Student queryById(long id);

}
