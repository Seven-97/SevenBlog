package com.qunar.mybatis.springboot.entity;

import com.qunar.mybatis.springboot.enums.BookStateEnum;

/**
 * Created with IntelliJ IDEA. User: guolifei Date: 2018/8/1
 * 图书实体
 */
public class Book {
    private long bookId;// 图书ID

    private String name;// 图书名称

    private int number;// 馆藏数量

    private BookStateEnum state = BookStateEnum.PUTAWAY;

    public Book() {
    }

    public Book(long bookId, String name, int number, BookStateEnum state) {
        this.bookId = bookId;
        this.name = name;
        this.number = number;
        this.state = state;
    }

    public long getBookId() {
        return bookId;
    }

    public void setBookId(long bookId) {
        this.bookId = bookId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public BookStateEnum getState() {
        return state;
    }

    public void setState(BookStateEnum state) {
        this.state = state;
    }

    @Override
    public String toString() {
        return "Book [bookId=" + bookId + ", name=" + name + ", number=" + number + "]";
    }
}
