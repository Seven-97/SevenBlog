#### ***文中链接各位根据自己项目对应修改***
--------------------------------------------------------------------------------
#### **项目管理**：
#### *PMO*:(http://pmo.corp.qunar.com)<br />
--------------------------------------------------------------------------------
#### **CI/CD**:
#### *QDR*:(http://qdr.corp.qunar.com/)<br />
#### *QCI*:(http://qci.corp.qunar.com/)<br />
#### *CABLE*:(http://wanshiwu.corp.qunar.com/qualitycheck/index/)<br />

--------------------------------------------------------------------------------
#### **质量管理**:
#### *bugfree*:(http://svn.corp.qunar.com/bugfree)<br />
#### *case*:(http://bugfree.corp.qunar.com/bugfree/index.php/case)<br />
--------------------------------------------------------------------------------
#### **项目信息**:
#### *wiki*:(http://wiki.corp.qunar.com/)<br />
